<!DOCTYPE html>
<html lang="en">

<?php include './Components/head.php'?>
<link rel="stylesheet" href="css/styleforLoginSignup.css">


<body>
<!-- Navbar Section Starts Here -->
<?php include './Components/navbarSignin.php'?>

<!-- Navbar Section Ends Here -->
<?php
            if (isset($_GET['error'])){
            if($_GET['error'] == 'emptyfields'){
                    echo '<p class="errorMessage">Fill in all fields</p>';
               }
               else if($_GET['error'] == 'invalidEmail'){
                   echo '<p class="errorMessage">Invalid email.Email must end with @epoka.edu.al</p>';
               }
               else if($_GET['error'] == 'invalidSurname'){
                   echo '<p class="errorMessage">Invalid Surname</p>';
                }
                else if($_GET['error'] == 'invalidName'){
                  echo '<p class="errorMessage">Invalid Name</p>';
                }
               else if($_GET['error'] == 'emailTaken'){
                    echo '<p class="errorMessage">This email is already taken.Please choose a different one.</p>';
               }else if($_GET['error'] == 'wrongPassword'){
                    echo '<p class="errorMessage">Wrong Password</p>';
               }
               else if($_GET['error'] == 'noAccess'){
                   echo '<p class="errorMessage">You do not have access to this page!</p>';
               }
           }
            if (isset($_GET['success']) && $_GET['success'] == 'signupsuccess') {
    echo '<p class="successMessage">Signup successful!</p>';} ?>
<div class="container" id="container">
    <div class="form-container sign-up-container">
        <form method="post" action="./Backend/registerFunction.php" accept-charset="UTF-8" class="customer-form">
            <h1>Create Account</h1>
            <div class="social-container">
                <a href="#" class="social"><i class="fab fa-google-plus-g"></i></a>
            </div>
            <span>or use your email for registration</span>
            <input type="text" name="fname" placeholder="Name" />
            <input type="text" name="sname" placeholder="Surname" />

            <input type="email" name="email" placeholder="Email" />
            <div class="password-container">
                <input type="password" id="passwordFieldSignup" name="psw" placeholder="Password" />
                <i id="eyeIconSignup" onclick="togglePasswordVisibility('passwordFieldSignup', 'eyeIconSignup')" class="fas fa-eye"></i>
            </div>
            <input name="signup" class="buttonSubmit" type="submit" value="Sign Up"/>
        </form>
    </div>
    <div class="form-container sign-in-container">
        <form method="post" action="./Backend/loginFunction.php" accept-charset="UTF-8" class="customer-form">
            <h1>Sign in</h1>
            <div class="social-container">
                <a href="#" class="social"><i class="fab fa-google-plus-g"></i></a>
            </div>
            <span>or use your account</span>
            <input type="email" name="email" placeholder="Email" />
            <div class="password-container">
                <input type="password" id="passwordFieldSignin" name="psw" placeholder="Password" />
                <i id="eyeIconSignin" onclick="togglePasswordVisibility('passwordFieldSignin', 'eyeIconSignin')" class="fas fa-eye"></i>
            </div>
            <a href="#">Forgot your password?</a>
            <input name="signin" class="buttonSubmit" type="submit" value="Sign In"/>
        </form>
    </div>
    <div class="overlay-container">
        <div class="overlay">
            <div class="overlay-panel overlay-left">
                <h1>Welcome Back!</h1>
                <p>To keep connected with us please login with your personal info</p>
                <button class="ghost" id="signIn">Sign In</button>
            </div>
            <div class="overlay-panel overlay-right">
                <h1>Hello, Friend!</h1>
                <p>Enter your personal details and start journey with us</p>
                <button class="ghost" id="signUp">Sign Up</button>
            </div>
        </div>
    </div>
</div>


<!-- fOOD Menu Section Ends Here -->

<!-- social Section Starts Here -->

<!-- social Section Ends Here -->

<!-- footer Section Starts Here -->
<script src="Javascript/signup.js"></script>

<?php include './Components/footer.php'?>

<!-- footer Section Ends Here -->

</body>
</html>