<!DOCTYPE html>
<html lang="en">
<?php 
include './Components/head.php';
include_once './backend/config.php'; 
$itemsPerPage = 6; 
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$course_id = $_GET['courseId'];
$start = ($page - 1) * $itemsPerPage;

// Fetch items from the database
$stmt = $conn->prepare("SELECT * FROM books WHERE bookCourseId = :courseId LIMIT :start, :itemsPerPage");
$stmt->bindParam(':start', $start, PDO::PARAM_INT);
$stmt->bindParam(':itemsPerPage', $itemsPerPage, PDO::PARAM_INT);
$stmt->bindParam(':courseId', $course_id, PDO::PARAM_INT);
$stmt->execute();
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

$totalItems = $conn->prepare("SELECT count(*) FROM books WHERE bookCourseId = :courseId");
$totalItems->bindParam(':courseId', $course_id, PDO::PARAM_INT);
$totalItems->execute();
$totalItemsCount = $totalItems->fetchColumn();
$totalPages = ceil($totalItemsCount / $itemsPerPage);

if(!isset($_SESSION['email'])){
    header('location: /bookhub/signup.php');
    exit();
} elseif($_SESSION['accessLevel'] != 1) {
    $previousPage = $_SESSION['previous_page'];
    header("location: $previousPage");
    exit();
}
?>
<body>
    <!-- Navbar Section Starts Here -->
    <?php include './Components/Navbar.php'; ?>
    
    <div class="container">
        <!-- Display items -->
        <?php if(count($items) > 0): ?>
            <div class="row">
                <?php foreach ($items as $key => $item): ?>
                      <div class="col-md-4">
                        <a href="bookSinglePage.php?idInput=<?php echo $item['bookID']; ?>">
                            <div class="box-3 float-container align-text-center">
                                <img src="./Backend/<?php echo $item['book_photopath']; ?>" alt="image" class="img-responsive img-curve" style="width: 180%; height: auto;">
                                <h2 class=""><?php echo $item['bookName']; ?></h2>
                            </div>
                        </a>
                    </div>
                    <?php if (($key + 1) % 3 == 0 && $key + 1 < count($items)): ?>
                        </div><div class="row">
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
            
            <!-- Pagination -->
            <nav aria-label="Page navigation example">
              <ul class="pagination">
                <li class="page-item <?php echo ($page <= 1) ? 'disabled' : ''; ?>"><a class="page-link" href="?courseId=<?php echo $course_id ?>&page=<?php echo ($page <= 1) ? 1 : ($page - 1); ?>">Previous</a></li>
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>"><a class="page-link" href="?courseId=<?php echo $course_id ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
                <?php endfor; ?>
                <li class="page-item <?php echo ($page >= $totalPages) ? 'disabled' : ''; ?>"><a class="page-link" href="?courseId=<?php echo $course_id ?>&page=<?php echo ($page >= $totalPages) ? $totalPages : ($page + 1); ?>">Next</a></li>
              </ul>
            </nav>
        <?php else: ?>
            <p>No books found.</p>
        <?php endif; ?>
    </div>
    
    <!-- footer Section Starts Here -->
    <?php include './Components/footer.php'; ?>
    <!-- footer Section Ends Here -->
    <style>
        .footer{
            bottom: 0;
            position: fixed;
            left:0;
            right:0;
        }
    </style>
</body>
</html>
