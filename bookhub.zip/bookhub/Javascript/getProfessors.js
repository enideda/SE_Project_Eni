$(document).ready(function () {
    let dataTable = $('#datatable').DataTable();

    $.ajax({
        url: 'backend/getProfessors.php',
        dataType: 'JSON',
        success: function (response) {
            appendToTable(response, dataTable);
        },
        error: function (error) {
            console.log(error);
        }
    });
});

function appendToTable(response, dataTable) {
    $(response).each(function (i,row){
        let tableData = {
            '0': row['professor_name'],
            '1': row['professor_surname'],
            '2': row['professor_email'],
            '3': row['Department'],
            '4': row['professor_lastlogin'] + '<a href="backend/deletePRofessor.php?id='+row["professor_id"]+'" class="delete Button text-decoration-none">Delete</a>'
        };
        dataTable.row.add(tableData);
        dataTable.draw();
    });

}