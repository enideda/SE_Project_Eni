$(document).ready(function () {
    let dataTable = $('#dataTable').DataTable();

    $.ajax({
        url: 'backend/getReviews.php',
        dataType: 'JSON',
        success: function (response) {
            appendToTable(response, dataTable);
        },
        error: function (error) {
            console.log(error);
        }
    });
    $(document).on('click','.delete', function (){
        let del = $(this);
        let id = $(this).parents('tr').children(':eq(0)').text();
        $.ajax({
            url: 'backend/deleteReview.php',
            data: id,
            dataType: 'text',
            success: function (response) {
                dataTable.row($(del).parents('tr')).remove().draw();
            },
            error: function (xhr) {
                console.log(xhr.responseText());
            }
        });
    });
});

function appendToTable(response, dataTable) {
    $(response).each(function (i,row){
        let tableData = {
            '0': row['review_id'],
            '1': row['review_title'],
            '2': row['review_description'],
            '3': row['username'],
            '4': row['usersurname'],
            '5': row['bookName'] + '<a href="backend/deleteReview.php?id='+row["review_id"]+'" class="delete Button text-decoration-none">Delete</a>'
        };
        dataTable.row.add(tableData);
        dataTable.draw();
    });

}