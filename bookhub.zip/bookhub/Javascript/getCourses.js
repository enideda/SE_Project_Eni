$(document).ready(function () {
    let dataTable = $('#dataTable').DataTable();

    $.ajax({
        url: 'backend/getCourses.php',
        dataType: 'JSON',
        success: function (response) {
            appendToTable(response, dataTable);
        },
        error: function (error) {
            console.log(error);
        }
    });
    $(document).on('click','.delete', function (){
        let del = $(this);
        let id = $(this).parents('tr').children(':eq(0)').text();
        $.ajax({
            url: 'backend/deletePost.php',
            data: id,
            dataType: 'text',
            success: function (response) {
                dataTable.row($(del).parents('tr')).remove().draw();
            },
            error: function (xhr) {
                console.log(xhr.responseText());
            }
        });
    });
});

function appendToTable(response, dataTable) {
    $(response).each(function (i,row){
        let tableData = {
            '0': row['course_id'],
            '1': row['course_name'],
            '2': row['department'],
            '3': row['course_code'],
            '4': row['course_grade'] + '<a href="backend/deleteCourse.php?id='+row["course_id"]+'" class="delete Button text-decoration-none">Delete</a>'
        };
        dataTable.row.add(tableData);
        dataTable.draw();
    });

}