$(document).ready(function () {
    let dataTable = $('#dataTable').DataTable();

    $.ajax({
        url: 'backend/getBooks.php',
        dataType: 'JSON',
        success: function (response) {
            appendToTable(response, dataTable);
        },
        error: function (error) {
            console.log(error);
        }
    });
    $(document).on('click','.delete', function (){
        let del = $(this);
        let id = $(this).parents('tr').children(':eq(0)').text();
        $.ajax({
            url: 'backend/deleteBook.php',
            data: id,
            dataType: 'text',
            success: function (response) {
                dataTable.row($(del).parents('tr')).remove().draw();
            },
            error: function (xhr) {
                console.log(xhr.responseText());
            }
        });
    });
});

function appendToTable(response, dataTable) {
    $(response).each(function (i,row){
        let tableData = {
            '0': row['bookID'],
            '1': row['bookName'],
            '2': row['bookDescription'],
            '3': row['bookAuthor'],
            '4': row['course_name'],
            '5': row['BookDateCreated'] + '<a href="backend/deleteBook.php?id='+row["bookID"]+'" class="delete Button text-decoration-none">Delete</a>'
        };
        dataTable.row.add(tableData);
        dataTable.draw();
    });

}