<!DOCTYPE html>
<html>
<?php
include './Components/head.php';

if(!isset($_SESSION['email'])){
    header('location: /bookhub/signup.php');
    exit();
} elseif($_SESSION['accessLevel'] != 1) {
    $previousPage = $_SESSION['previous_page'];
    header("location: $previousPage");
    exit();
}
?>
<link rel="stylesheet" href="css/singlePage.css">

<body>
<!-- Navbar Section Starts Here -->
<?php include './Components/Navbar.php'; ?>

<?php
if (isset($_GET['error'])){
    if($_GET['error'] == 'reviewcouldnotsent'){
        echo '<p class="errorMessage">Review could not be sent</p>';
    }
}
if(isset($_GET['success']) && $_GET['success'] == 'reviewSent') {
    echo '<p class="successMessage">Review uploaded successfully!</p>';
}
?>
<!-- Navbar Section Ends Here -->
<?php include "./Backend/bookSinglePageFunc.php"; ?>

<?php
$input = $_GET['idInput'];

// Set the $_GET parameter before including the file
$_GET['idInput'] = $input;
include "./Backend/getBookReviews.php";
?>

<!-- footer Section Starts Here -->
<?php include './Components/footer.php'; ?>
<!-- footer Section Ends Here -->
</body>
</html>
