<!DOCTYPE html>
<html lang="en">

<?php require('components/headerAdmin.php');?>

<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <?php require('components/sidebarProfessor.php');?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <?php require('components/navbarAdmin.php');?>
            <!-- End of Topbar -->
            <?php
            if (isset($_GET['error'])){
                if($_GET['error'] == 'emptyfields'){
                    echo '<p class="errorMessage">Fill in all fields</p>';
                }
                else if($_GET['error'] == 'bothfieldsfilled'){
                    echo '<p class="errorMessage">Invalid selection.Both download link and file upload can not be chosen</p>';
                }
                else if($_GET['error'] == 'filetoolarge'){
                    echo '<p class="errorMessage">File is too large</p>';
                }
                else if($_GET['error'] == 'fileerror'){
                    echo '<p class="errorMessage">File Error</p>';
                }
                else if($_GET['error'] == 'invalidfiletype'){
                    echo '<p class="errorMessage">Invalid file type you can only choose pdf, doc, docx, txt</p>';
                }else if($_GET['error'] == 'wrongPassword'){
                    echo '<p class="errorMessage">Wrong Password</p>';
                }
                else if($_GET['error'] == 'noAccess'){
                    echo '<p class="errorMessage">You do not have access to this page!</p>';
                }
                else if($_GET['error'] == 'uploadfailed'){
                    echo '<p class="errorMessage">Upload failed!</p>';
                }
                else if($_GET['error'] == 'sqlerror'){
                    echo '<p class="errorMessage">Sql error !</p>';
                }
            }
            if (isset($_GET['success']) && $_GET['success'] == 'courseuploaded') {
                echo '<p class="successMessage">Course uploaded successfully!</p>';} ?>
            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <h1 class="h3 mb-2 text-gray-800">Create Course</h1>
                <hr>

                <!-- DataTales Example -->
                <div class="form-group row mb-2 justify-content-center">
                    <div class="col-lg-8 col-12">
                        <!-- Your form elements go here -->
                        <form class="user" action="./Backend/addCourse.php" method="POST" enctype="multipart/form-data">
                            <div class="form-group row">
                                <div class="col-lg-6">
                                    <label class="h5 text-gray-700 pt-2" for="Name">Course Name</label>
                                    <input type="text" class="form-control" name="Name" id="Name" placeholder="Course Name" required>
                                </div>
                                <div class="col-lg-6">
                                    <label class="h5 text-gray-700 pt-2" for="Code">Course Code</label>
                                    <input type="text" class="form-control" name="Code" id="Code" placeholder="Course Code" required>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-lg-6">
                                    <label class="h5 text-gray-700 pt-2" for="Department">Department</label>
                                        <select class="form-control" name="Department" id="Department">
                                            <option value="Faculty of Engineering And Architecture">Faculty of Engineering And Architecture</option>
                                            <option value="Faculty of Business and Economy">Faculty of Business and Economy</option>
                                        </select>
                                </div>
                                <div class="col-lg-6">
                                    <label class="h5 text-gray-700 pt-2" for="CourseGrade">Course Grade</label>
                                    <select class="form-control" name="CourseGrade" id="CourseGrade">
                                        <option value="BINF-3 A">BINF-3 A</option>
                                        <option value="BINF-3 B">BINF-3 B</option>
                                        <option value="BINF-3 C">BINF-3 C</option>
                                        <option value="SWE-3 A">SWE-3 A</option>
                                        <option value="SWE-3 B">SWE-3 B</option>
                                        <option value="SWE-3 C">SWE-3 C</option>

                                    </select>
                                </div>
                            </div>
                            <div class="form-group row mb-2 justify-content-center">
                                <div class="col-lg-6 col-md-6 col-12">
                                    <button name="submit" type="submit" class="btn btn-primary btn-user btn-block d-block my-1 my-lg-0 save">Save Book</button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
                <hr>
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <?php include 'components/footer.php'?>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="Javascript/main.js"></script>

<!-- Custom scripts for all pages-->
<script src="Javascript/sb-admin-2.min.js"></script>
<!-- Custom script for functionality -->
<script src="Javascript/createPost.js"></script>

</body>

</html>
