<?php

use PHPUnit\Framework\TestCase;

require_once './Backend/userClass.php';

class userClassTest extends TestCase {
    public function testInsertToDatabase() {
        // Create a mock PDO object
        $pdo = $this->createMock(PDO::class);

        // Set up expectations for the PDO::prepare method
        $pdo->expects($this->once())
            ->method('prepare')
            ->with('INSERT INTO users (username, usersurname, user_email, user_password) VALUES (:name, :surname, :email, :Password)')
            ->willReturn($this->createMock(PDOStatement::class));

        // Create a User object
        $user = new User('John', 'Doe', 'john@epoka.edu.al', 'password');

        // Call the insertToDatabase method
        $user->insertToDatabase($pdo);
    }
}
