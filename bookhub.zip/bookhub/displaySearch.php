<!DOCTYPE html>
<html lang="en">

<?php include './Components/head.php'?>


<body>
<!-- Navbar Section Starts Here -->
<?php include './Components/Navbar.php'?>

<!-- Navbar Section Ends Here -->


<!-- SEARCH Section Starts Here -->

<!-- SEARCH Section Ends Here -->

<!-- CAtegories Section Starts Here -->
<section class="categories">
    <div class="container">
        <h2 class="text-center ">Search Results</h2>


        <?php include('./backend/searchFunction.php'); ?>


        <div class="clearfix"></div>
    </div>
</section>
<!-- Categories Section Ends Here -->

<!-- fOOD Menu Section Ends Here -->

<!-- social Section Starts Here -->

<!-- social Section Ends Here -->

<!-- footer Section Starts Here -->
<?php include './Components/footer.php'?>

<!-- footer Section Ends Here -->

</body>
</html>