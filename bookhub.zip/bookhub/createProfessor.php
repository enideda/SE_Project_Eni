<!DOCTYPE html>
<html lang="en">

<?php require('components/headerAdmin.php');?>

<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <?php require('components/sidebarAdmin.php');?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <?php require('components/navbarAdmin.php');?>
            <!-- End of Topbar -->
            <?php
            if (isset($_GET['error'])){
                if($_GET['error'] == 'emptyfields'){
                    echo '<p class="errorMessage">Fill in all fields</p>';
                }
                else if($_GET['error'] == 'invalidEmail'){
                    echo '<p class="errorMessage">Invalid email.Email must end with @epoka.edu.al</p>';
                }
                else if($_GET['error'] == 'invalidSurname'){
                    echo '<p class="errorMessage">Invalid Surname</p>';
                }
                else if($_GET['error'] == 'invalidName'){
                    echo '<p class="errorMessage">Invalid Name</p>';
                }
                else if($_GET['error'] == 'emailTaken'){
                    echo '<p class="errorMessage">This email is already taken.Please choose a different one.</p>';
                }else if($_GET['error'] == 'wrongPassword'){
                    echo '<p class="errorMessage">Wrong Password</p>';
                }
                else if($_GET['error'] == 'noAccess'){
                    echo '<p class="errorMessage">You do not have access to this page!</p>';
                }
            }
            if (isset($_GET['success']) && $_GET['success'] == 'signupsuccess') {
                echo '<p class="successMessage">Signup successful!</p>';} ?>
            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <h1 class="h3 mb-2 text-gray-800">Create Professor</h1>
                <hr>

                <!-- DataTales Example -->
                <div class="form-group row mb-2 justify-content-center">
                    <div class="col-lg-8 col-12">
                        <!-- Your form elements go here -->
                        <form class="user" action="./Backend/addProfessor.php" method="POST">
                            <div class="form-group row">
                                <div class="col-lg-6">
                                    <label class="h5 text-gray-700 pt-2" for="Name">Name</label>
                                    <input type="text" class="form-control" name="Name" id="Name" placeholder="Name">
                                </div>
                                <div class="col-lg-6">
                                    <label class="h5 text-gray-700 pt-2" for="Surname">Surname</label>
                                    <input type="text" class="form-control" name="Surname" id="Surname" placeholder="Surname">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-lg-6">
                                    <label class="h5 text-gray-700 pt-2" for="Email">Email</label>
                                    <input type="text" class="form-control" name="Email" id="Email" placeholder="Email">
                                </div>
                                <div class="col-lg-6">
                                    <label class="h5 text-gray-700 pt-2" for="Password">Password</label>
                                    <div class="input-group">
                                        <input type="password" name="Password" class="form-control" id="Password" placeholder="Password">
                                        <div class="input-group-append">
                                            <span class="input-group-text">
                                                <i class="fas fa-eye" id="togglePassword" onclick="togglePasswordVisibilityProf()"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-lg-12">
                                    <label class="h5 text-gray-700 pt-2" for="Department">Department</label>
                                    <select class="form-control" name="Department" id="Department">
                                        <option value="Faculty of Engineering And Architecture">Faculty of Engineering And Architecture</option>
                                        <option value="Faculty of Business and Economy">Faculty of Business and Economy</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-lg-12 justify-content-center d-flex my-3">
                                    <img class="preview" src="">
                                </div>
                            </div>
                            <div class="form-group row mb-2 justify-content-center">
                                <div class="col-lg-6 col-md-6 col-12">
                                    <button name="submit" type="submit" class="btn btn-primary btn-user btn-block d-block my-1 my-lg-0 save">Save Changes</button>
                                </div>
                                <div class="col-lg-6 col-md-6 col-12">
                                    <button class="btn btn-danger btn-user btn-block d-block my-1 my-lg-0" onclick="window.location.reload();">Discard Changes</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <hr>
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <?php include 'components/footer.php'?>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" href="faqjaLogin.php">Logout</a>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="Javascript/sb-admin-2.min.js"></script>
<!-- Custom script for functionality -->
<script src="Javascript/createPost.js"></script>

</body>

</html>
