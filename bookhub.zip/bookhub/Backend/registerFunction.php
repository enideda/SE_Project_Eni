<?php
if(isset($_POST["signup"])){
    $name = $_POST['fname'];
    $surname = $_POST['sname'];
    $email = $_POST['email'];
    $pwd = $_POST['psw'];

    include_once 'userFunctions/userfunction.php';
    include_once 'config.php';
    include_once 'userClass.php';


    if (empty($_POST['fname']) || empty($_POST['sname']) || empty($_POST['email']) || empty($_POST['psw'])) {
        header("Location: /bookhub/signup.php?error=emptyfields");
        exit();
    }

    if (invalidName($name)){
        header("location: /bookhub/signup.php?error=invalidName");
        exit();
    }

    if (invalidSurname($surname)){
        header("location: /bookhub/signup.php?error=invalidSurname");
        exit();
    }

    if (invalidEmail($email)){
        header("location: /bookhub/signup.php?error=invalidEmail");
        exit();
    }

    if (emailTaken($conn, $email)){
        header("location: /bookhub/signup.php?error=emailTaken");
        exit();
    }


    $newUser = new User($name, $surname, $email, $pwd);
    $newUser->insertToDatabase($conn);

    header("location: /bookhub/signup.php?success=signupsuccess");
}else{
    header("location: /bookhub//signup.php");
}

