<?php

if(isset($_POST["signin"])){
    // Retrieve login credentials
    $logInEmail = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $logInPassword = $_POST['psw'];
    $dateLoggedIn = date('Y-m-d H:i:s');

    require_once 'userFunctions/userfunction.php';
    require_once 'config.php';

    // Check for empty fields
    if (isSignInEmpty($logInEmail, $logInPassword)){
        header("location: /bookhub/signup.php?error=emptyfields");
        exit();
    }

    if (invalidEmail($logInEmail)){
        header("location: /bookhub/signup.php?error=invalidEmail");
        exit();
    }

    // Check users table for login
    $query = "SELECT * FROM users WHERE user_email = :email AND user_password = :hashedPassword";
    $stmt = $conn->prepare($query);
    $hashedPassword = hash('md5', $logInPassword);
    $stmt->bindParam(':email', $logInEmail, PDO::PARAM_STR);
    $stmt->bindParam(':hashedPassword', $hashedPassword, PDO::PARAM_STR);
    $stmt->execute();

    if (!$stmt->fetch(PDO::FETCH_ASSOC)){

        // If not found in users table, check professors table
        $query = "SELECT * FROM professors WHERE professor_email = :email AND professor_pass = :hashedPassword";
        $stmtProfessor = $conn->prepare($query);
        $hashedPassword = hash('md5', $logInPassword);
        $stmtProfessor->bindParam(':email', $logInEmail, PDO::PARAM_STR);
        $stmtProfessor->bindParam(':hashedPassword', $hashedPassword, PDO::PARAM_STR);
        $stmtProfessor->execute();

        $professorData = $stmtProfessor->fetch(PDO::FETCH_ASSOC);

        if (!$professorData) {
            // Neither user nor professor found with provided credentials
            header("location: /bookhub/signup.php?error=wrongPassword");
            exit();
        } else {
            // Professor login successful
            session_start();
            LogInUpdateProfessor($conn, $dateLoggedIn, $logInEmail);

            // Save professor ID in session
            $_SESSION["professor_id"] = $professorData["professor_id"];
            $_SESSION["accessLevel"] = $professorData["prof_accessLevel"];


            $_SESSION["email"] = $logInEmail;
            // Retrieve user data
            

            header("location: /bookhub/professorsDashboard.php");
            exit();
        }
    } else {
        // User login successful
        session_start();
        LogInUpdate($conn, $dateLoggedIn, $logInEmail);
        $_SESSION["email"] = $logInEmail;
        // Retrieve user data
        $query = "SELECT * FROM users WHERE user_email = :email ";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':email', $logInEmail, PDO::PARAM_STR);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        // Store user data in session
        $_SESSION['id'] = $result["userid"];
        $_SESSION['username'] = $result["username"];
        $_SESSION['usersurname'] = $result["usersurname"];
        $_SESSION['accessLevel'] = $result["user_accesslevel"];
        $_SESSION['user_grade'] = $result["user_grade"];

        // Redirect based on user type
        if(validateUser($conn, $logInEmail) == 1){
            header("location: /bookhub/index.php");
        } elseif(validateUser($conn, $logInEmail) == 0){
            header("location: /bookhub/adminDashboard.php");
        }
    }
} else {
    // Redirect to signup page if signin button not pressed
    header("location: /bookhub/signup.php");
}
?>
