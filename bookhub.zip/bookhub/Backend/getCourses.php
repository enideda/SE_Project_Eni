<?php
session_start();

require_once('config.php');
$professorID = $_SESSION["professor_id"];
$query = "SELECT * from courses where professor_id = :professor_id";
//$query = "SELECT * from courses";
$stm = $conn->prepare($query);
$stm->bindParam(':professor_id', $professorID, PDO::PARAM_STR);

$stm->execute();

$res = $stm->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($res);