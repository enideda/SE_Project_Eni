<?php

function isSignUpEmpty($name, $surname, $email, $password)
{
    return empty($name) || empty($surname) || empty($email) || empty($password);
}

function invalidName($name)
{
    return !preg_match("/^[a-zA-Z]*$/", $name);
}

function invalidSurname($surname)
{
    return !preg_match("/^[a-zA-Z]*$/", $surname);
}

function invalidEmail($email)
{
    if (substr($email, -13) !== "@epoka.edu.al") {
        return true;
    }

    return false;
}



function emailTaken($pdo, $email)
{
    $query = "SELECT * FROM users WHERE user_email = :email";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);

    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);



}

function isSignInEmpty($email, $password){
    return empty($email) || empty($password);
}


function passwordExists($pdo, $email, $password) {
    $query = "SELECT * FROM users WHERE user_email = :email AND user_password = :hashedPassword";
    $stmt = $pdo->prepare($query);

    $hashedPassword = hash('md5', $password);

    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    $stmt->bindParam(':hashedPassword', $hashedPassword, PDO::PARAM_STR);
    $stmt->execute();

    return  $stmt->fetch(PDO::FETCH_ASSOC);

}

function LogInUpdate($pdo, $dateLoggedIn, $email) {
    $query = "UPDATE users SET LastLogIn = :dateLoggedIn WHERE user_email = :email";
    $stmt = $pdo->prepare($query);

    $stmt->bindParam(':dateLoggedIn', $dateLoggedIn, PDO::PARAM_STR);
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    $stmt->execute();
}

function LogInUpdateProfessor($pdo, $dateLoggedIn, $email) {
    $query = "UPDATE professors SET professor_lastlogin = :dateLoggedIn WHERE professor_email = :email";
    $stmt = $pdo->prepare($query);

    $stmt->bindParam(':dateLoggedIn', $dateLoggedIn, PDO::PARAM_STR);
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    $stmt->execute();
}
function validateUser($pdo, $email) {
    $query = "SELECT user_accesslevel FROM users WHERE user_email = :email";
    $stmt = $pdo->prepare($query);

    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($result) {
        return $result['user_accesslevel'];

    }
}

