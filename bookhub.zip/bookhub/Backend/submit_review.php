<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
if(isset($_POST["submit"])){
    $title = $_POST['reviewTitle'];
    $message = $_POST['reviewMessage'];
    $input = $_POST['idInput'];
    $dateOfReview = date('Y-m-d H:i:s');
    include_once 'config.php';

    $userID = $_SESSION["id"];

    $query = "INSERT INTO reviews (review_title, review_description, review_book_id, review_userid, review_time) VALUES (:title, :message, :bookId, :user_id, :dateOfReview)";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':title', $title, PDO::PARAM_STR);
    $stmt->bindParam(':message', $message, PDO::PARAM_STR);
    $stmt->bindParam(':bookId', $input, PDO::PARAM_STR);
    $stmt->bindParam(':user_id', $userID, PDO::PARAM_STR);
    $stmt->bindParam(':dateOfReview', $dateOfReview, PDO::PARAM_STR);


    $stmt->execute();

    header("location: /bookhub/bookSinglePage.php?idInput=$input&success=reviewSent"); // Corrected the concatenation
} else {
    header("location: /bookhub/bookSinglePage.php?error=reviewcouldnotsent");
}
?>
