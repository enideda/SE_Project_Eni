<?php

session_set_cookie_params([
    'lifetime' => 1800,
    'domain' => 'localhost',
    'path' => '/',
    'secure' => true,
    'httponly' => true
]);

session_start();

//function regenerateSession(){
//    session_regenerate_id();
//    $_SESSION['last_regeneration'] = time();
//}

session_regenerate_id();


//if(!isset($_SESSION['last_regeneration '])) {
//    regenerateSession();
//}else{
//    $interval = 1800;
//    if(time() - $_SESSION['last_regeneration '] >= $interval){
//        regenerateSession();
//    }
//}

