<?php
require_once('config.php');
$userGrade = $_SESSION['user_grade'];

$stm = $conn->prepare("SELECT c.*, p.professor_name, p.professor_surname
                      FROM courses c
                      JOIN professors p ON c.professor_id = p.professor_id
                      WHERE c.course_grade = :user_grade;");
//$stm = $conn->prepare("SELECT * from courses
//                      WHERE course_grade = :user_grade;");
$stm->bindParam(':user_grade', $userGrade);
$stm->execute();
$result = $stm->fetchAll(PDO::FETCH_ASSOC);
$response = array();
$html = '';


if (count($result) > 0) {
    foreach ($result as $row) {
        $response[] = $row;
        $html .= '
<div class="ag-courses_item">
                        <a href="displayCourses.php?courseId='. $row['course_id'].'&page=1" class="ag-courses-item_link">
                            <div class="ag-courses-item_bg"></div>

                            <div class="ag-courses-item_title">'. $row['course_name'] .'
                            </div>

                            <div class="ag-courses-item_date-box">
                                Prof.
                                <span class="ag-courses-item_date">
                                '. $row['professor_name'].' '. $row['professor_surname'].'
                              </span>
                            </div>
                        </a>
                    </div>';
    }
    echo $html;

} else {

    echo "No posts found.";
}
?>