<?php

require_once('config.php');

$stm = $conn->prepare("SELECT r.review_id, r.review_title, r.review_description, u.username, u.usersurname, b.bookName FROM reviews r, books b, users u WHERE r.review_book_id  = b.bookID and r.review_userid = userid");

$stm->execute();
$res = $stm->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($res);