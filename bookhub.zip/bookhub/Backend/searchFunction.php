<?php
require_once('config.php');

if (isset($_GET['searchTerm'])) {
    $searchInput = $_GET['searchTerm'];

    if (!empty($searchInput)) {
        $userGrade = $_SESSION['user_grade'];

        // Modify the search input to be used with LIKE
        $searchInputForCourse = '%' . $searchInput . '%';
        $searchInputForBook = '%' . $searchInput . '%';

        $courseStm = $conn->prepare("
            SELECT p.*, c.course_id, c.course_name
            FROM Books p
            INNER JOIN courses c ON p.bookCourseId = c.course_id
            WHERE c.course_grade = :user_grade AND c.course_name LIKE :course
        ");

        $bookStm = $conn->prepare("
            SELECT p.*, NULL AS course_id, NULL AS course_name
            FROM Books p
            WHERE p.bookName LIKE :input AND p.bookCourseId IN (
                SELECT course_id FROM courses WHERE course_grade = :user_grade
            )
        ");

        // Bind parameters for the course search
        $courseStm->bindParam(':user_grade', $userGrade, PDO::PARAM_INT);
        $courseStm->bindParam(':course', $searchInputForCourse, PDO::PARAM_STR);

        // Bind parameters for the book search
        $bookStm->bindParam(':input', $searchInputForBook, PDO::PARAM_STR);
        $bookStm->bindParam(':user_grade', $userGrade, PDO::PARAM_INT);

        // Execute the statements
        $courseStm->execute();
        $bookStm->execute();

        $resultCourse = $courseStm->fetchAll(PDO::FETCH_ASSOC);
        $resultBook = $bookStm->fetchAll(PDO::FETCH_ASSOC);

        // Combine and filter out duplicates
        $mergedResults = array_merge($resultBook, $resultCourse);
        $uniqueResults = [];
        $uniqueBookIDs = [];

        foreach ($mergedResults as $row) {
            if (!in_array($row['bookID'], $uniqueBookIDs)) {
                $uniqueBookIDs[] = $row['bookID'];
                $uniqueResults[] = $row;
            }
        }

        $html = '';

        if (count($uniqueResults) > 0) {
            foreach ($uniqueResults as $row) {
                $myPhotoPath = './Backend/' . $row['book_photopath'];

                if (empty($row['book_photopath'])) {
                    $myPhotoPath = " ";
                }
                $html .= '<a href="product-layout1.php?idInput=' . $row['bookID'] . '">
                    <div class="box-3 float-container align-text-center">
                        <img src="' . $myPhotoPath . '" alt="image" class="img-responsive img-curve">
                        <h2 class="">' . $row['bookName'] . '</h2>
                    </div>
                </a>';
            }

            echo $html;
        } else {
            echo 'No Books Found';
        }
    } else {
        echo 'No Books Found';
    }
} else {
    echo 'No search term provided';
}
?>
