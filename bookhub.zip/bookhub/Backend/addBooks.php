<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_POST["submit"])) {
    $name = $_POST['Name'];
    $author = $_POST['Author'];
    $description = $_POST['Description'];
    $course = $_POST['Course'];
    $downloadLink = $_POST['DownloadLink'];
    $file = $_FILES['file'];
    $coverPhoto = $_FILES['CoverPhoto'];
    $dateCreated = date('Y-m-d H:i:s');

    include_once 'config.php';

    // Debugging: Check if form is submitted
    echo "Form submitted<br>";

    // Check if fields are empty
    if (empty($name) || empty($author) || empty($description) || empty($course) || empty($coverPhoto) || (empty($_FILES['file']['name']) && empty($downloadLink))) {
        header("Location: /bookhub/createBook.php?error=emptyfields");
        exit();
    }

    if (!empty($_FILES['file']['name']) && !empty($downloadLink)) {
        header("Location: /bookhub/createBook.php?error=bothfieldsfilled");
        exit();
    }

    $targetDir = "uploads/";

    // Ensure the target directory exists, if not, create it
    if (!is_dir($targetDir)) {
        if (!mkdir($targetDir, 0777, true)) {
            die('Failed to create directory: ' . $targetDir);
        }
    }

    // Handle Cover Photo Upload
    if (!empty($coverPhoto)) {
        $coverPhotoName = $_FILES['CoverPhoto']['name'];
        $coverPhotoTmpName = $_FILES['CoverPhoto']['tmp_name'];
        $coverPhotoSize = $_FILES['CoverPhoto']['size'];
        $coverPhotoError = $_FILES['CoverPhoto']['error'];
        $coverPhotoType = $_FILES['CoverPhoto']['type'];

        $coverPhotoExt = explode('.', $coverPhotoName);
        $coverPhotoActualExt = strtolower(end($coverPhotoExt));
        $allowed = array('jpg', 'jpeg', 'png', 'gif');

        if (in_array($coverPhotoActualExt, $allowed)) {
            if ($coverPhotoError === 0) {
                if ($coverPhotoSize < 5000000) { // 5MB max
                    $coverPhotoNewName = uniqid('', true) . "." . $coverPhotoActualExt;
                    $coverPhotoDestination = $targetDir . $coverPhotoNewName;

                    // Move the uploaded file to the target directory
                    if (move_uploaded_file($coverPhotoTmpName, $coverPhotoDestination)) {
                        echo "The cover photo " . htmlspecialchars(basename($coverPhotoName)) . " has been uploaded successfully.";
                    } else {
                        echo "Sorry, there was an error uploading your cover photo.";
                    }
                } else {
                    header("Location: /bookhub/createBook.php?error=coverphototoolarge");
                    exit();
                }
            } else {
                header("Location: /bookhub/createBook.php?error=coverphotoerror");
                exit();
            }
        } else {
            header("Location: /bookhub/createBook.php?error=invalidcoverphototype");
            exit();
        }
    }

    // Handle Book File Upload
    $fileNameNew = null;
    if (!empty($_FILES['file']['name'])) {
        // File upload handling
        $fileName = $_FILES['file']['name'];
        $fileTmpName = $_FILES['file']['tmp_name'];
        $fileSize = $_FILES['file']['size'];
        $fileError = $_FILES['file']['error'];
        $fileType = $_FILES['file']['type'];

        $fileExt = explode('.', $fileName);
        $fileActualExt = strtolower(end($fileExt));
        $allowed = array('pdf', 'doc', 'docx', 'txt');

        if (in_array($fileActualExt, $allowed)) {
            if ($fileError === 0) {
                if ($fileSize < 10000000) { // 10MB max
                    $fileNameNew = uniqid('', true) . "." . $fileActualExt;
                    $fileDestination = $targetDir . $fileNameNew;

                    // Move the uploaded file to the target directory
                    if (move_uploaded_file($fileTmpName, $fileDestination)) {
                        echo "The file " . htmlspecialchars(basename($fileName)) . " has been uploaded successfully.";
                    } else {
                        echo "Sorry, there was an error uploading your file.";
                    }
                } else {
                    header("Location: /bookhub/createBook.php?error=filetoolarge");
                    exit();
                }
            } else {
                header("Location: /bookhub/createBook.php?error=fileerror");
                exit();
            }
        } else {
            header("Location: /bookhub/createBook.php?error=invalidfiletype");
            exit();
        }
    }

    $professorID = $_SESSION["professor_id"];


    // Insert book details into the database
    $sql = "INSERT INTO books (bookName, bookAuthor, bookDescription, bookCourseId, book_photopath, book_downloadpath, book_filepath, BookDateCreated, booksProfessorsID)
            VALUES (:name, :author, :description, :course, :coverPhoto, :downloadLink, :file, :dateCreated, :booksProfessorsID)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':author', $author);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':course', $course);
    $stmt->bindParam(':coverPhoto', $coverPhotoDestination); // Save the cover photo path
    $stmt->bindParam(':downloadLink', $downloadLink);
    $stmt->bindParam(':file', $fileDestination); // Your existing file path
    $stmt->bindParam(':dateCreated', $dateCreated);
    $stmt->bindParam(':booksProfessorsID', $professorID);


    if ($stmt->execute()) {
        header("Location: /bookhub/createBook.php?success=bookadded");
        exit();
    } else {
        header("Location: /bookhub/createBook.php?error=sqlerror");
        exit();
    }
}
?>
