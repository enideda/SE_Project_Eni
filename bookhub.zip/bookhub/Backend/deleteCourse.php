<?php
require_once('config.php');
if(isset($_GET["id"])) {
    $stm = $conn->prepare("DELETE FROM courses WHERE course_id = :id;");
    $stm->bindParam('id', $_GET['id']);

    $stm->execute();
    $res = $stm->fetchAll(PDO::FETCH_ASSOC);
    header('Location: /bookhub/coursesListed.php');
}
