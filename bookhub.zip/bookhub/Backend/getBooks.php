<?php
session_start();

require_once('config.php');

$professorID = $_SESSION["professor_id"];

$stm = $conn->prepare("SELECT b.bookID, b.bookName, b.bookAuthor, b.bookDescription, c.course_name, b.BookDateCreated FROM books b, courses c WHERE b.bookCourseId  = c.course_id and b.booksProfessorsID = :professor_id");
$stm->bindParam(':professor_id', $professorID, PDO::PARAM_STR);

$stm->execute();
$res = $stm->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($res);