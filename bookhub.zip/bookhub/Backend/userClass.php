<?php

class User{
    private $name;
    private $surname;
    private $email;
    private $pwd;

    function __construct($name, $surname, $email, $pwd){
        $this->name = $name;
        $this->surname = $surname;
        $this->email = $email;
        $this->pwd = $pwd;
    }

    public function insertToDatabase($conn){
        $query = "INSERT INTO users (username, usersurname, user_email, user_password) VALUES (:name, :surname, :email, :Password)";
        $stmt = $conn->prepare($query);

        $Password = hash('md5', $this->pwd);

        $stmt->bindParam(':name', $this->name, PDO::PARAM_STR);
        $stmt->bindParam(':surname', $this->surname, PDO::PARAM_STR);
        $stmt->bindParam(':email', $this->email, PDO::PARAM_STR);
        $stmt->bindParam(':Password', $Password, PDO::PARAM_STR);
        $stmt->execute();
    }
}