<?php
if(isset($_POST["submit"])){
    $name = $_POST['Name'];
    $surname = $_POST['Surname'];
    $email = $_POST['Email'];
    $pwd = $_POST['Password'];
    $department = $_POST['Department'];


    include_once 'userFunctions/userfunction.php';
    include_once 'config.php';
    include_once 'userClass.php';


    if (empty($_POST['Name']) || empty($_POST['Surname']) || empty($_POST['Email']) || empty($_POST['Password']) || empty($_POST['Department'])) {
        header("Location: /bookhub/createProfessor.php?error=emptyfields");
        exit();
    }

    if (invalidName($name)){
        header("location: /bookhub/createProfessor.php?error=invalidName");
        exit();
    }

    if (invalidSurname($surname)){
        header("location: /bookhub/createProfessor.php?error=invalidSurname");
        exit();
    }

    if (invalidEmail($email)){
        header("location: /bookhub/createProfessor.php?error=invalidEmail");
        exit();
    }

    if (emailTaken($conn, $email)){
        header("location: /bookhub/createProfessor.php?error=emailTaken");
        exit();
    }


    $query = "INSERT INTO professors (professor_name, professor_surname, professor_email, professor_pass, department) VALUES (:name, :surname, :email, :Password, :Department)";
    $stmt = $conn->prepare($query);

    $Password = hash('md5', $pwd);

    $stmt->bindParam(':name', $name, PDO::PARAM_STR);
    $stmt->bindParam(':surname', $surname, PDO::PARAM_STR);
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    $stmt->bindParam(':Password', $Password, PDO::PARAM_STR); // Use $Password here
    $stmt->bindParam(':Department', $department, PDO::PARAM_STR);

    $stmt->execute();

    header("location: /bookhub/createProfessor.php?success=signupsuccess");
}else{
    header("location: /bookhub/createProfessor.php");
}
?>
