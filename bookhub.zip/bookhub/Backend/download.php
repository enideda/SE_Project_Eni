<?php
require_once("config.php");

if (isset($_GET['file'])) {
    $file = $_GET['file'];

    // Ensure the file exists
    if (file_exists($file)) {
        // Force download
        header('Pragma: public');
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Cache-Control: private', false); // required for certain browsers 
        header('Content-Type: application/pdf'); // You might want to dynamically determine the content type
        header('Content-Disposition: attachment; filename="' . basename($file) . '";');
        header('Content-Transfer-Encoding: binary');
        header('Content-Length: ' . filesize($file));

        readfile($file);
        exit;
    } else {
        echo "File not found.";
    }
} else {
    echo "No file specified.";
}
?>
