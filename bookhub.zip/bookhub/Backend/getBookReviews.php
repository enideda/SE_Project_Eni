<?php
require_once("config.php");
error_reporting(E_ALL);
ini_set('display_errors', 1);
if (isset($_GET['idInput'])) {
    $bookID = $_GET['idInput'];

    if (!empty($bookID) && is_numeric($bookID)) {
        $stm = $conn->prepare("SELECT r.*, u.username FROM reviews r JOIN users u ON u.userid = r.review_userid WHERE r.review_book_id = :idInput");
        $stm->bindParam(':idInput', $bookID);
        $stm->execute();
        $result = $stm->fetchAll(PDO::FETCH_ASSOC);
        $response = array();
        $html = '';

        if (count($result) > 0) {
            foreach ($result as $row) {
                $response[] = $row;

                $html .= '
                <div class="review">
                    <div class="review-header">
                        <span class="username">' . htmlspecialchars($row['username']) . '</span>
                        <span class="time">' . htmlspecialchars($row['review_time']) . '</span>
                    </div>
                    <div class="review-body">
                        <span class="title">' . htmlspecialchars($row['review_title']) . '</span>
                        <p class="message">' . htmlspecialchars($row['review_description']) . '</p>
                    </div>
                </div>';
            }
            echo $html;
        } else {
            echo '<p>No reviews found for this book.</p>';
        }
    } else {
        echo '<p>IdInput is missing or invalid.</p>';
    }
}
?>
