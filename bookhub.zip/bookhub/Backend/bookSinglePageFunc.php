<?php
require_once("config.php");
if (isset($_GET['idInput'])) {
    $input = $_GET['idInput'];

    if (!empty($input) && is_numeric($input)) {
        $stm = $conn->prepare("SELECT * FROM books b WHERE b.bookID = :idInput");
        $stm->bindParam(':idInput', $input);
        $stm->execute();
        $result = $stm->fetchAll(PDO::FETCH_ASSOC);
        $response = array();
        $html = '';

        if (count($result) > 0) {
            foreach ($result as $row) {
                $response[] = $row;
                $myPhotoPath = './Backend/' . $row['book_photopath'];

                if ($row['book_photopath'] == "") {
                    $myPhotoPath = " ";
                }

                $filename = $row['book_filepath']; // of course find the exact filename....        


                $filename = $row['book_filepath'];
                $downloadPath = $row['book_downloadpath'];
                $downloadLink = '';

                // Determine which link to use
                if (!empty($downloadPath)) {
                    $downloadLink = '<a href="' . htmlspecialchars($downloadPath) . '" class="btn btn-primary">Download</a>';
                } elseif (!empty($filename)) {
                    $downloadLink = '<a href="./backend/download.php?file=' . urlencode($filename) . '" class="btn btn-primary">Download</a>';
                }

                $html .= '
                <div class="book-container">
                    <div class="book-photo">
                        <img src="' . $myPhotoPath . '" alt="image" class="img-responsive img-curve">
                    </div>
                    <div class="book-details">
                        <h1>' . $row['bookName'] . '</h1>
                        <h2>' . $row['bookAuthor'] . '</h2>
                        <p>' . $row['bookDescription'] . '</p>
                        ' . $downloadLink . '
                        <div class="book-reviews">
                            <!-- Placeholder for book reviews -->
                        </div>
                        <button id="reviewButton" class="btn btn-secondary" onclick="toggleReviewForm()">Write a Review</button>
                        <div id="reviewForm" style="display:none;">
                            <form action="./backend/submit_review.php" method="POST">
                                <input type="hidden" name="bookID" value="' . $row['bookID'] . '">
                                <input type="hidden" name="idInput" value="' . $input . '">
                                <div>
                                    <label for="reviewTitle">Title:</label>
                                    <input type="text" id="reviewTitle" name="reviewTitle" required>
                                </div>
                                <div>
                                    <label for="reviewMessage">Message:</label>
                                    <textarea id="reviewMessage" name="reviewMessage" required></textarea>
                                </div>
                                <button type="submit" name="submit" class="btn btn-primary">Submit Review</button>
                            </form>
                        </div>
                    </div>
                </div>';
            }
            echo $html;
        } else {
            echo 'No book found with the given ID.';
        }
    } else {
        echo 'IdInput is missing or invalid.';
    }
}
?>
