<?php
session_start();
if(isset($_POST["submit"])){
    $name = $_POST['Name'];
    $code = $_POST['Code'];
    $grade = $_POST['CourseGrade'];
    $department = $_POST['Department'];

    include_once 'userFunctions/userfunction.php';
    include_once 'config.php';
    include_once 'userClass.php';

    $professorID = $_SESSION["professor_id"];


    if (empty($_POST['Name']) || empty($_POST['Code']) || empty($_POST['CourseGrade']) || empty($_POST['Department'])) {
        header("Location: /bookhub/createProfessor.php?error=emptyfields");
        exit();
    }


    $query = "INSERT INTO courses (course_name, course_code, course_grade, department, professor_id) VALUES (:name, :code, :grade, :Department, :professor_id)";
    $stmt = $conn->prepare($query);

    $Password = hash('md5', $pwd);

    $stmt->bindParam(':name', $name, PDO::PARAM_STR);
    $stmt->bindParam(':code', $code, PDO::PARAM_STR);
    $stmt->bindParam(':grade', $grade, PDO::PARAM_STR);
    $stmt->bindParam(':Department', $department, PDO::PARAM_STR);
    $stmt->bindParam(':professor_id', $professorID, PDO::PARAM_STR);

    $stmt->execute();

    header("location: /bookhub/createCourse.php?success=courseuploaded");
}else{
    header("location: /bookhub/createCourse.php");
}
?>
