<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once('config.php');
//session_start();

$userGrade = $_SESSION['user_grade'];

$stm = $conn->prepare("SELECT * FROM books WHERE bookCourseID IN (SELECT course_id FROM courses WHERE course_grade = :user_grade) ORDER BY BookDateCreated ASC LIMIT 3;");

$stm->bindParam(':user_grade', $userGrade);
$stm->execute();
$result = $stm->fetchAll(PDO::FETCH_ASSOC);
$response = array();
$html = '';


if (count($result) > 0) {
    foreach ($result as $row) {
        $response[] = $row;
        $myPhotoPath = './Backend/'. $row['book_photopath'];

        if($row['book_photopath'] == ""){
            $myPhotoPath = " ";
        }
        $html .= '
<a href="bookSinglePage.php?idInput=' . $row['bookID']  . '">
            <div class="box-3 float-container align-text-center">
                <img src="'. $myPhotoPath .'" alt="image" class="img-responsive img-curve">
                                <h2 class="">'. $row['bookName'] . '</h2>

        </div>
            </a>';
    }
    echo $html;

} else {

    echo '';
}
?>