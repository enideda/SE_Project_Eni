<?php
require_once('config.php');

$stm = $conn->prepare("SELECT professor_id, professor_name, professor_surname, professor_email, Department, professor_lastlogin FROM professors");
$stm->execute();
$res = $stm->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($res);