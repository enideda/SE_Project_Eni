    <!DOCTYPE html>

    <html lang="en">

    <?php include './Components/head.php';

    if(!isset($_SESSION['email'])){
        header('location: /bookhub/signup.php');
        exit();
    } elseif($_SESSION['accessLevel'] != 1) {
        $previousPage = $_SESSION['previous_page'];
        header("location: $previousPage");
            exit();
    }
    ?>


    <body>
        <!-- Navbar Section Starts Here -->
        <?php include './Components/Navbar.php'?>

        <!-- Navbar Section Ends Here -->

        <section class="homePage">
            <div class="homeInfo">
                <div class="homeText">
                    <!-- <h1 class="homeUpperText">About</h1> -->
                    <h1 class="homeLowText">About<span class="blueHomeLowText">Us</span></h1>

                    <!-- <div class="homeParagraph">
                        <h3 class="underText">Welcome to our university book store,
                            where knowledge knows no bounds! </h3>
                    </div> -->
                    <div class="aboutContent">
                <p>Welcome to Epoka BookHub, your go-to source for all your academic reading materials! Our mission is to support your educational journey by providing easy access to a wide range of books and resources. Whether you're a student, a professor, or a lifelong learner, our collection is curated to meet your needs and help you succeed.</p>
                
                <p>Founded with a passion for education and a commitment to excellence, Epoka BookHub is more than just a bookstore; it's a community. We believe that books are the gateway to knowledge and empowerment, and we strive to make them accessible to everyone in our university community.</p>
                <p>Join us in fostering a culture of learning and growth. Thank you for choosing Epoka BookHub – where every book is a step towards a brighter future.</p>
            </div>
                    

                </div>

                <div class="homeImg">
                    <img src="images/Saly-16.png" alt="Cover Image">
                </div>
            </div>
        </section>

        
            


        <!-- footer Section Starts Here -->
        <?php include './Components/footer.php'?>
        <style>
            .footer{
                bottom: 0;
                left: 0;
                right: 0;
                position: fixed;
            }
        </style>

        <!-- footer Section Ends Here -->

    </body>
    </html>