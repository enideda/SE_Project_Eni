<!DOCTYPE html>
<html lang="en">

<?php include './Components/head.php'?>


<body>
<!-- Navbar Section Starts Here -->
<?php include './Components/navbarSignin.php'?>

<!-- Navbar Section Ends Here -->

    <div class="homeLogin">
        <div class="blueHalf">
            <h1 class="homeUpperText">Epoka</h1>
            <h1 class="homeLowText">Book<span class="whiteHomeLowText">Hub</span></h1>
        </div>

        <div class="whiteHalf">
            <form method="post" action="./Backend/loginFunction.php" id="CustomerRegisterForm" accept-charset="UTF-8" class="customer-form">
                <h1>Sign In</h1>
                <div class="form-group">
                    <label for="CustomerEmail">Email <span class="required">*</span></label>
                    <div class="input-group">
                        <input type="email" name="email" placeholder="example@epoka.edu.al" id="CustomerEmail" class="form-control">
                        <span class="underline"></span> <!-- Line below input -->
                    </div>
                </div>
                <div class="form-group">
                    <label for="CustomerPassword">Password <span class="required">*</span></label>
                    <div class="input-group">
                        <input type="password" value="" name="password" placeholder="" id="CustomerPassword" class="form-control">
                        <span class="underline"></span> <!-- Line below input -->
                    </div>
                </div>
                <div class="text-left">
                    <input type="submit" class="btn mb-3" value="Sign In" name="submit">
                    <p class="mb-4">
                        <a href="forgot-your-password.php">Forgot your password?</a> &nbsp; | &nbsp;
                        <a href="signup.php" id="customer_register_link">Create account</a>
                    </p>
                    <div class="google-login">
                        <a href="#" class="btn-google"><img src="./images/googleLogo.png" alt="Google Logo"> Sign in with Google</a>
                    </div>
                </div>
            </form>
        </div>
    </div>


<!-- fOOD Menu Section Ends Here -->

<!-- social Section Starts Here -->

<!-- social Section Ends Here -->

<!-- footer Section Starts Here -->
<?php include './Components/footer.php'?>

<!-- footer Section Ends Here -->

</body>
</html>