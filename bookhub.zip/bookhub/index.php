<!DOCTYPE html>

<html lang="en">

<?php include './Components/head.php';

if(!isset($_SESSION['email'])){
    header('location: /bookhub/signup.php');
    exit();
} elseif($_SESSION['accessLevel'] != 1) {
    $previousPage = $_SESSION['previous_page'];
    header("location: $previousPage");
        exit();
}
?>


<body>
    <!-- Navbar Section Starts Here -->
    <?php include './Components/Navbar.php'?>

    <!-- Navbar Section Ends Here -->

    <section class="homePage">
        <div class="homeInfo">
            <div class="homeText">
                <h1 class="homeUpperText">Epoka</h1>
                <h1 class="homeLowText">Book<span class="blueHomeLowText">Hub</span></h1>

                <div class="homeParagraph">
                    <h3 class="underText">Welcome to our university book store,
                        where knowledge knows no bounds! </h3>
                </div>

                <div class="buttons">
                    <button class="btn">
                        Welcome!
                    </button>
                </div>
               

            </div>

            <div class="homeImg">
                <img src="images/coverImg.png" alt="Cover Image">
            </div>
        </div>
    </section>


    <!-- SEARCH Section Starts Here -->
   
    <!-- SEARCH Section Ends Here -->

    <!-- CAtegories Section Starts Here -->

    <!-- Categories Section Ends Here -->

    <section class="coursesSection">
        <div class="container">
            <h2 class="text-center">Courses</h2>

            <div class="ag-format-container">
                <div class="ag-courses_box">

                    <?php include('./Backend/addCourseCards.php'); ?>

<!--                    <div class="ag-courses_item">-->
<!--                        <a href="#" class="ag-courses-item_link">-->
<!--                            <div class="ag-courses-item_bg"></div>-->
<!---->
<!--                            <div class="ag-courses-item_title">-->
<!--                                UX/UI Web-Design&#160;+ Mobile Design-->
<!--                            </div>-->
<!---->
<!--                            <div class="ag-courses-item_date-box">-->
<!--                                Prof.-->
<!--                                <span class="ag-courses-item_date">-->
<!--                                  Ari Gjerazi-->
<!--                              </span>-->
<!--                            </div>-->
<!--                        </a>-->
<!--                    </div>-->





                </div>
            </div>
    </section>



    <!-- footer Section Starts Here -->
    <?php include './Components/footer.php'?>

    <!-- footer Section Ends Here -->

</body>
</html>