
<section class="navbar">
    <div class="menuContainer">
        <div class="logo">
            <a href="index.php" title="Logo">
                <div class="logoImage">
                    <img src="images/logo.png" alt="Restaurant Logo" class="img-responsive">
                </div>
                <div class="titleText">
                    <h2 class="upperText">BookHub</h2>
                    <h6 class="underText">Online Book Store</h6>
                </div>
            </a>
        </div>



        <div class="clearfix"></div>
    </div>
</section>
