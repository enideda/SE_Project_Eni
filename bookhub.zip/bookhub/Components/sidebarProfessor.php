<html lang="en">
<ul class="navbar-nav bg-custom-color sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="professorsDashboard.php">
        <div class="sidebar-brand-icon ">
            <i class="fas fa-fw fa-tachometer-alt"></i>
        </div>
        <div class="sidebar-brand-text mx-3">BookHub Professor</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item">
        <a class="nav-link" href="professorsDashboard.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Interface
    </div>
<!--    <li class="nav-item">-->
<!--        <a class="nav-link py-2" href="professors.php">-->
<!--            <i class="fas fa-fw fa-tachometer-alt"></i>-->
<!--            <span>Professors</span></a>-->
<!--    </li>-->
    <li class="nav-item">
        <a class="nav-link py-2" href="booksListed.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Books</span></a>
    </li>
        <li class="nav-item">
            <a class="nav-link py-2" href="coursesListed.php">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span>Courses</span></a>
        </li>


    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>
</html>