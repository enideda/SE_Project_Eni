
<section class="navbar">
    <div class="menuContainer">
        <div class="logo">
            <a href="index.php" title="Logo">
                <div class="logoImage">
                <img src="images/logo.png" alt="Restaurant Logo" class="img-responsive">
                </div>
                <div class="titleText">
                    <h2 class="upperText">BookHub</h2>
                    <h6 class="underText">Online Book Store</h6>
                </div>
            </a>
        </div>

        <div class="menu text-right">
            <ul>
            <li>
                    <a href="index.php">
                        Home
                    </a>
                </li>
            <li>
                    <a href="displayAllBooks.php">
                        Courses
                    </a>
                </li>
                <li>
                    <a href="aboutUs.php">
                        About Us
                    </a>
                </li>
            </ul>
        </div>

        <div class="menu icons">
            <ul>
                <li>
                    <a href="myaccount.php">
                        <i class="fa-solid fa-user"></i>
                    </a>
                </li>

                <li>
<!--                    <a href="foods.php">-->
<!--                        <i class="fa-sharp fa-solid fa-magnifying-glass"></i>-->
                    <div class="outsiteSearch">
                        <div class="search-box">
                            <form class="search-bar__form" action="displaySearch.php" method="GET">
                            <button class="btn-search" type="submit"><i class="fas fa-search"></i></button>
                            <input type="search" name="searchTerm" value="" class="input-search" placeholder="Type to Search..." />
                            </form>
                        </div>
                    </div>
<!--                    </a>-->
                </li>
            </ul>
        </div>


        <div class="clearfix"></div>
    </div>
</section>
