<section class="footer">
    <footer id="sticky-footer" class="">
        <div class=" text-center">
            <large class="text-white">Copyright &copy; Eni Deda</large>
        </div>
    </footer>
    <script src="./Javascript/main.js"></script>
</section>

